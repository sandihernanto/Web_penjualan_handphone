<!DOCTYPE html>
<html>
<head>
    <title>Tentang Kami - Bantull Cell</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        
        .container {
            width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        h1 {
            text-align: center;
        }
        
        p {
            line-height: 1.5;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
    <div class="container">
        <h1>Tentang Kami - Bantull Cell</h1>
        
        <center><p>Selamat datang di Bantull Cell, toko handphone terpercaya dan terlengkap di kota ini.</p></center>
        
        <h2>Visi</h2>
        <p>Visi kami adalah menjadi penyedia terkemuka dalam penjualan dan pelayanan produk handphone dengan kualitas terbaik.</p>
        
        <h2>Misi</h2>
        <p>Misi kami adalah memberikan pengalaman berbelanja handphone yang menyenangkan dan memuaskan kepada pelanggan, dengan menyediakan produk handphone terbaik, harga kompetitif, pelayanan yang cepat, dan dukungan teknis yang handal.</p>
        
        <h2>Produk</h2>
        <p>Kami menawarkan berbagai macam handphone dari merek terkenal, termasuk Apple, Samsung, Xiaomi, dan lainnya. Kami juga menyediakan aksesoris handphone seperti casing, pelindung layar, charger, dan baterai cadangan.</p>
        
        <h2>Kontak</h2>
        <p>Jika Anda memiliki pertanyaan atau ingin mendapatkan informasi lebih lanjut, jangan ragu untuk menghubungi kami melalui telepon di nomor 085211345654 atau melalui email di info@bantullcell.com.</p>
    </div>
    <div class="clearfix" style="padding-top:10%;"></div>
    </section>
    </section>
    </div>
    </div>
</body>
</html>
